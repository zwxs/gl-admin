<template>
  <div class="mod-home">
    后台管理
  </div>
</template>

<script>
  export default {
  }
</script>

<style>
</style>

