const indexDB = {
  indexedDB: window.indexedDB || window.webkitindexedDB,
  IDBKeyRange: window.IDBKeyRange || window.webkitIDBKeyRange,
  msbDatabase: {
    name: "msb_ybj",
    version: 1,
    db: null,
    ojstore: [
      {
        name: "filesInfo", // 存储空间表的名字
        keypath: "id" // 主键
      }
    ]
  },
  drawDatabase: {
    name: "database",
    version: 2,
    db: null,
    ojstore: [
      {
        name: "files", // 存储空间表的名字
        keypath: "title" // 主键
      },
      {
        name: "filesInfo", // 存储空间表的名字
        keypath: "title" // 主键
      },
      {
        name: "objects", // 存储空间表的名字
        keypath: "key" // 主键
      }
    ]
  },
  openDB: function(myDB2, callback) {
    // 建立或打开数据库，建立对象存储空间(ObjectStore)
    const myDB = myDB2;
    const self = this;
    const version = myDB.version || 1;
    const request = self.indexedDB.open(myDB.name, version);
    request.onerror = function(e) {
      console.log(e.currentTarget.error.message);
    };
    request.onsuccess = function(e) {
      myDB.db = e.target.result;
      // console.log('成功建立并打开数据库')
      callback(myDB.db);
      // console.log(e)
    };
    request.onupgradeneeded = function(e) {
      const db = e.target.result;
      // const transaction = e.target.transaction
      myDB.ojstore.forEach(element => {
        if (!db.objectStoreNames.contains(element.name)) {
          // 没有该对象空间时创建该对象空间
          db.createObjectStore(element.name, {
            keyPath: element.keypath
          });
          // console.log('成功建立对象存储空间：' + myDB.ojstore.name)
        }
        // console.log(e)
      });
    };
  },
  deletedb: function(dbname) {
    // 删除数据库
    const self = this;
    self.indexedDB.deleteDatabase(dbname);
    // console.log(dbname + '数据库已删除')
  },
  closeDB: function(db) {
    // 关闭数据库
    db.close();
    // console.log('数据库已关闭')
  },
  addData: function(db, storename, data) {
    // 添加数据，重复添加会报错
    const self = this;
    const store = db.transaction(storename, "readwrite").objectStore(storename);
    for (let i = 0; i < data.length; i++) {
      const request = store.add(data[i]);
      request.onerror = function() {
        // console.log('add添加数据库中已有该数据')
        self.putData(db, storename, data);
      };
      request.onsuccess = function() {
        // console.log('add添加数据已存入数据库')
      };
    }
  },
  putData: function(db, storename, data, idname) {
    // 添加数据，重复添加会更新原有数据
    for (let i = 0; i < data.length; i++) {
      if (data[i][idname]) {
        const modData = data[i];
        const store = db
          .transaction(storename, "readwrite")
          .objectStore(storename);
        const request = store.put(modData);
        request.onerror = function() {
          // console.log('add添加数据库中已有该数据')
        };
        request.onsuccess = function() {
          console.log("add添加数据已存入数据库");
        };
        this.getDataByKey(db, storename, modData[idname], res2 => {
          try {
            const res = res2;
            // res.totalCount += modData.totalCount
            const store = db
              .transaction(storename, "readwrite")
              .objectStore(storename);
            const request = store.put(res);
            request.onsuccess = function() {
              // console.log('put添加数据已存入数据库')
            };
          } catch (err) {}
        });
      }
    }
  },
  getAllData(db, storename, callback) {
    try {
      // 获取所有数据
      const store = db
        .transaction(storename, "readwrite")
        .objectStore(storename);
      const allRecords = store.getAll();
      allRecords.onsuccess = function() {
        // console.log(allRecords.result)
        if (typeof callback === "function") {
          callback(allRecords.result);
        }
      };
    } catch (err) {}
  },
  getDataByKey: function(db, storename, key, callback) {
    // 根据存储空间的键找到对应数据
    const store = db.transaction(storename, "readwrite").objectStore(storename);
    const request = store.get(key);
    request.onerror = function() {
      // console.log('getDataByKey error')
    };
    request.onsuccess = function(e) {
      const result2 = e.target.result;
      // console.log('查找数据成功', result2)
      if (typeof callback === "function") {
        callback(result2);
      }
    };
  },
  deleteData: function(db, storename, key) {
    // 删除某一条记录
    const store = db.transaction(storename, "readwrite").objectStore(storename);
    store.delete(key);
    // console.log('已删除存储空间' + storename + '中' + key + '记录')
  },
  clearData: function(db, storename) {
    // 删除存储空间全部记录
    const store = db.transaction(storename, "readwrite").objectStore(storename);
    store.clear();
    // console.log('已删除存储空间' + storename + '全部记录')
  }
};
// ****************添加数据****************************
// this.$indexDB.addData(myDB.db, myDB.ojstore.name, cartData)
// ****************获取所有数据****************************
// this.$indexDB.getAllData(myDB.db, myDB.ojstore.name)
// *******************put重复添加*************************
// this.$indexDB.putData(myDB.db,myDB.ojstore.name,cartData)
// *******************获取指定数据*************************'
// this.$indexDB.getDataByKey(
// myDB.db,
// myDB.ojstore.name,
// cartData[0].id
// )
// ******************删除数据1001************
// this.$indexDB.deleteData(myDB.db,myDB.ojstore.name,1001)
// ******************删除全部数据************
// this.$indexDB.clearData(myDB.db,myDB.ojstore.name)
// ******************关闭数据库************
// this.$indexDB.closeDB(myDB.db)
// ******************删除数据库************
// this.$indexDB.deletedb(myDB.name)
export default indexDB;
