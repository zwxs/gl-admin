/*
 * @Author: your name
 * @Date: 2021-03-22 17:26:36
 * @LastEditTime: 2021-05-08 20:44:10
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: /note_web/src/utils/api.js
 */
import request from "./request";

// 短信登陆
export function loginBySmscode(data) {
  return request({
    url: "app/loginBySmscode",
    method: "post",
    data
  });
}

// 获取登录发送验证码
export function loginSms(data) {
  return request({
    url: "app/loginSms",
    method: "post",
    data
  });
}
// 获取文件树
export function getAllDirTree(type) {
  return request({
    url: `app/getAllCollectionDirTree/${type}`,
    method: "get"
  });
}

// 新增文件
export function mkNoteDir(data) {
  return request({
    url: "app/mkNoteDir",
    method: "post",
    data
  });
}
// 新增文件
export function saveFile(data) {
  return request({
    url: "app/saveFile",
    method: "post",
    data
  });
}

// 修改文件夹
export function updateNoteDir(data) {
  return request({
    url: "app/updateNoteDir",
    method: "post",
    data
  });
}

// 获取文件内容
export function getContentById(id) {
  return request({
    url: `note/notecontent/info/${id}`,
    method: "get"
  });
}
// 获取文件内容
export function getMyContentById(data) {
  return request({
    url: `app/getMyContentById`,
    method: "get",
    params: data
  });
}
// 获取文件内容
export function getShareContentById(data) {
  return request({
    url: `app/getShareContentById`,
    method: "post",
    data
  });
}
// 获取文件内容
export function getShareContent(data) {
  return request({
    url: `app/getShareContent`,
    method: "post",
    data
  });
}

// 保存到文件
export function saveContentById(data) {
  return request({
    url: `app/saveFile`,
    method: "post",
    ...data
  });
}

// 保存到文件
export function saveContentViewById(localId, content, contentView) {
  let data = {
    localId: localId,
    noteContent: content,

    noteViewContent: contentView,
    remote: "1"
  };
  return request({
    url: `app/saveFile`,
    method: "post",
    data
  });
}

// 收藏到文件夹
export function addCollection(data) {
  return request({
    url: `app/addCollection`,
    method: "post",
    data
  });
}

//获取验证图片  以及token
export function reqGet(data) {
  return request({
    url: "captcha/get",
    method: "post",
    data
  });
}

//滑动或者点选验证
export function reqCheck(data) {
  return request({
    url: "captcha/check",
    method: "post",
    data
  });
}

// 分享接口
export function addShare(data) {
  return request({
    url: "app/addShare",
    method: "post",
    data
  });
}

// 获取文件分享
export function myShare(data) {
  return request({
    url: "app/getShareList",
    method: "post",
    data
  });
}

export function getUserInfo() {
  let data = {};
  return request({
    url: "app/userInfo",
    method: "get",
    data
  });
}

export function showLogin() {
  let data = {};
  return request({
    url: "api/v1/system/showLogin",
    method: "post",
    data
  });
}

// 首页左侧菜单接口
export function findNoteDir() {
  let data = {};
  return request({
    url: "app/findNoteDir",
    method: "post",
    data
  });
}
// 首页右侧列表接口
export function getAllDirList(data) {
  return request({
    url: "app/getAllDirList",
    method: "post",
    data
  });
}
// 单文件夹树接口
export function getAllOnlyDirTree(data) {
  return request({
    url: "app/getAllOnlyDirTree",
    method: "get",
    data
  });
}
// 文件移动接口
export function moveNoteContent(data) {
  return request({
    url: "app/moveNoteContent",
    method: "post",
    data
  });
}
// 文件夹移动接口
export function moveNoteDir(data) {
  return request({
    url: "app/moveNoteDir",
    method: "post",
    data
  });
}
// 批量移动接口
export function batchMove(data) {
  return request({
    url: "app/batchMove",
    method: "post",
    data
  });
}

// 文件文件夹收藏接口
export function addNoteCollection(data) {
  return request({
    url: "app/addNoteCollection",
    method: "post",
    data
  });
}

// 收藏列表接口
export function findCollectionList(data) {
  return request({
    url: "app/findCollectionList",
    method: "post",
    data
  });
}

// 取消收藏接口
export function cancelNoteCollection(data) {
  return request({
    url: "app/cancelNoteCollection",
    method: "post",
    data
  });
}

// 新建文件或文件夹分享
export function addDirAndContentShare(data) {
  return request({
    url: `app/addDirAndContentShare`,
    method: "post",
    data
  });
}
// 新建多文件或文件夹分享
export function addMultipleShare(data) {
  return request({
    url: `app/addMultipleShare`,
    method: "post",
    data
  });
}
// 查询我的分享
export function findShareList(data) {
  return request({
    url: `app/findShareList`,
    method: "post",
    data
  });
}

// 查看分享是否需要密码
export function findShareInfoIsNeedPwd(id) {
  return request({
    url: `app/findShareInfoIsNeedPwd/${id}`,
    method: "get"
  });
}

// 校验分享密码是否正确
export function checkShareInfoPwd(data) {
  return request({
    url: "app/checkShareInfoPwd",
    method: "post",
    data
  });
}

// 查询分享文件/文件夹信息
export function findShareInfoByIdAndType(data) {
  return request({
    url: "app/findShareInfoByIdAndType",
    method: "post",
    data
  });
}
// 查询我的分享
export function findMultipleShare(data) {
  return request({
    url: `app/findMultipleShare`,
    method: "post",
    data
  });
}

// 删除 文件/文件夹 新
export function deleteNoteOrDirByLocalId(data) {
  return request({
    url: "app/deleteNoteOrDirByLocalId",
    method: "post",
    data
  });
}

// 查询我的回收站列表
export function getAllDeletedList(data) {
  return request({
    url: "app/getAllDeletedList",
    method: "post",
    data
  });
}

// 彻底删除文件 / 文件夹
export function completelyDelByLocalId(data) {
  return request({
    url: "app/completelyDelByLocalId",
    method: "post",
    data
  });
}

// 批量删除文件 / 文件夹
export function batchDelete(data) {
  return request({
    url: "app/batchDelete",
    method: "post",
    data
  });
}

// 克隆文件
export function cloneNoteContent(data) {
  return request({
    url: "app/cloneNoteContent",
    method: "post",
    data
  });
}

// 批量克隆文件
export function batchCloneNoteContent(data) {
  return request({
    url: "app/batchCloneNoteContent",
    method: "post",
    data
  });
}

// 取消分享文件
export function cancelShare(data) {
  return request({
    url: "app/cancelShare",
    method: "post",
    data
  });
}

// 查询分享文件夹列表
export function findShareDirList(data) {
  return request({
    url: "app/findShareDirList",
    method: "post",
    data
  });
}

// 获取新建文件默认编号
export function findTitleNum(data) {
  return request({
    url: "app/findTitleNum",
    method: "post",
    data
  });
}

// 文件搜索
export function searchAllDirList(data) {
  return request({
    url: "app/searchAllDirList",
    method: "post",
    data
  });
}

// 批量保存
export function batchSave(data) {
  return request({
    url: "app/batchSave",
    method: "post",
    data
  });
}

// 退出登录
export function logout(data) {
  return request({
    url: "app/logout",
    method: "get",
    params: data
  });
}

// 新增收藏

export function addCollect(data) {
  return request({
    url: "app/addCollect",
    method: "post",
    data
  });
}
