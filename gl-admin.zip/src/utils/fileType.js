let fileType = [
  {
    title: "富文本",
    key: "10",
    slots: {
      icon: "project"
    },
    id: "10",
    templateId: ""
  },
  // {
  //   title: "超富文本",
  //   key: "11",
  //   slots: {
  //     icon: "project",
  //   },
  //   id: "11",
  //   templateId: "",
  // },
  {
    title: "Markdown",
    key: "20",
    slots: {
      icon: "project"
    },
    id: "20",
    templateId: ""
  },
  {
    title: "白板画图",
    key: "50",
    slots: {
      icon: "project"
    },
    id: "50",
    templateId: ""
  },
  // {
  //   title: "画图文件",
  //   key: "30",
  //   slots: {
  //     icon: "project",
  //   },
  //   id: "30",
  //   templateId: "",
  // },
  {
    title: "流程图",
    key: "80",
    slots: {
      icon: "project"
    },
    id: "80",
    templateId: "11"
  },
  {
    title: "思维导图",
    key: "40",
    slots: {
      icon: "project"
    },
    id: "40",
    templateId: ""
  },
  {
    title: "原型图",
    key: "70",
    slots: {
      icon: "project"
    },
    id: "70",
    templateId: "51"
  },
  {
    title: "网络拓扑图",
    key: "110",
    slots: {
      icon: "project"
    },
    id: "110",
    templateId: "21"
  },
  {
    title: "UML",
    key: "60",
    slots: {
      icon: "project"
    },
    id: "60",
    templateId: "31"
  },
  {
    title: "Excel",
    key: "90",
    slots: {
      icon: "project",
    },
    id: "90",
    templateId: "",
  },
  {
    title: "PPT",
    key: "100",
    slots: {
      icon: "project"
    },
    id: "100",
    templateId: ""
  },
  // {
  //   title: "文件夹",
  //   key: "00",
  //   slots: {
  //     icon: "project"
  //   },
  //   id: "00",
  //   templateId: ""
  // }
];

module.exports = fileType;
