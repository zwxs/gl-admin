'use strict'
module.exports = {
  NODE_ENV: '"production"',
  VUE_APP_PREVIEW: true,
  VUE_APP_API_BASE_URL: '"https://note-api-beta.mashibing.cn/note-service"',
  VUE_APP_API_NOTE_BASE_URL: '"https://note-api-beta.mashibing.cn/note-service/note"',
  VUE_APP_NOTE_BASE_URL: '"https://cloud-test.fynote.com/"',
  VUE_APP_WS_API: '"wss://cloud-api-test.fynote.com"',
}
